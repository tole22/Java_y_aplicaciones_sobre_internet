package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Solicitud_En_Autorizacion;

public interface ISolicitud_En_AutorizacionDao extends GenericDao<Solicitud_En_Autorizacion> {

}
