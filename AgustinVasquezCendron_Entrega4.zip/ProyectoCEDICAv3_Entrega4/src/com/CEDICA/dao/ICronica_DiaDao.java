package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Cronica_Dia;

public interface ICronica_DiaDao extends GenericDao<Cronica_Dia> {

}
