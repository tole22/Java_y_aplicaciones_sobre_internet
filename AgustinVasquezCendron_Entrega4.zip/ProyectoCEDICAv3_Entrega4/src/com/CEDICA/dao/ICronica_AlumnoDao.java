package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Cronica_Alumno;

public interface ICronica_AlumnoDao extends GenericDao<Cronica_Alumno> {

}
