package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Familiar;

public interface IFamiliarDao extends GenericDao<Familiar> {

}
