package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Cronica_Profesional;

public interface ICronica_ProfesionalDao extends GenericDao<Cronica_Profesional> {

}
