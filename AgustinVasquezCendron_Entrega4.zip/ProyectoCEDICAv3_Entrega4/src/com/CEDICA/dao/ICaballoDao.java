package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Caballo;

public interface ICaballoDao extends GenericDao<Caballo> {

}
