package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Solicitud_En_Evaluacion;

public interface ISolicitud_En_EvaluacionDao extends GenericDao<Solicitud_En_Evaluacion> {

}
