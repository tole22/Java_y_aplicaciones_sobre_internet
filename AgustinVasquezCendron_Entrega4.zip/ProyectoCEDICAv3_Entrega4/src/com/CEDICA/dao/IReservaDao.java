package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Reserva;

public interface IReservaDao extends GenericDao<Reserva> {

}
