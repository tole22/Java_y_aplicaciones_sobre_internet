package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Legajo;

public interface ILegajoDao extends GenericDao<Legajo> {

}
