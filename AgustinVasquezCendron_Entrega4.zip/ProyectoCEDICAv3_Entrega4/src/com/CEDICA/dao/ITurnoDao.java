package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Turno;

public interface ITurnoDao extends GenericDao<Turno> {

}
