package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Clase_Taller;

public interface IClase_TallerDao extends GenericDao<Clase_Taller> {

}
