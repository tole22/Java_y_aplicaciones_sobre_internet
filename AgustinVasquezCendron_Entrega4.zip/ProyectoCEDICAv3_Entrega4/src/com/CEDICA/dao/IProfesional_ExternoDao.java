package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Profesional_Externo;

public interface IProfesional_ExternoDao extends GenericDao<Profesional_Externo> {

}
