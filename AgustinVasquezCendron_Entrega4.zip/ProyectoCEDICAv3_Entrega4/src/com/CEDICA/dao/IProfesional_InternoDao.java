package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Profesional_Interno;

public interface IProfesional_InternoDao extends GenericDao<Profesional_Interno> {

}
