package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.RegistroOperaciones;

public interface IRegistroOperacionesDAO extends GenericDao<RegistroOperaciones> {

}
