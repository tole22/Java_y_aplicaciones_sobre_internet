package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Grilla;

public interface IGrillaDao extends GenericDao<Grilla> {

}
