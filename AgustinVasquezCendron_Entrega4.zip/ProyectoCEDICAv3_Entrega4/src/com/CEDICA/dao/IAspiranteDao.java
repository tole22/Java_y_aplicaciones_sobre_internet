package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Aspirante;

public interface IAspiranteDao extends GenericDao<Aspirante> {

}
