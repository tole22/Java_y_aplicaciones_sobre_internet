package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Voluntario;

public interface IVoluntarioDao extends GenericDao<Voluntario> {

}
