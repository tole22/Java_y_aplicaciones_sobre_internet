package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Coordinador;

public interface ICoordinadorDao extends GenericDao<Coordinador> {

}
