package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Clase_Individual;

public interface IClase_IndividualDao extends GenericDao<Clase_Individual> {

}
