package com.CEDICA.dao.impl;

import java.io.Serializable;


import com.CEDICA.dao.IRolDao;
import com.CEDICA.dao.generic.GenericDaoHibernetJpaImpl;
import com.CEDICA.model.Rol;

public class RolDao extends GenericDaoHibernetJpaImpl<Rol> implements IRolDao {

	

}
