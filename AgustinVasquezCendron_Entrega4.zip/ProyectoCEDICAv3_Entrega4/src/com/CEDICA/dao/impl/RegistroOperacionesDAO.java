package com.CEDICA.dao.impl;

import com.CEDICA.dao.IRegistroOperacionesDAO;
import com.CEDICA.dao.generic.GenericDaoHibernetJpaImpl;
import com.CEDICA.model.RegistroOperaciones;

public class RegistroOperacionesDAO extends GenericDaoHibernetJpaImpl<RegistroOperaciones> implements
IRegistroOperacionesDAO{

}
