package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Solicitud_En_Admision;

public interface ISolicitud_En_AdmisionDao extends GenericDao<Solicitud_En_Admision> {

}
