package com.CEDICA.dao;

import com.CEDICA.dao.generic.GenericDao;
import com.CEDICA.model.Sede;

public interface ISedeDao extends GenericDao<Sede> {

}
