package com.CEDICA.model;





public class Conductor extends  Rol_En_Clase {
	public Voluntario voluntario;

	public Voluntario getVoluntario() {
		return voluntario;
	}

	public void setVoluntario(Voluntario voluntario) {
		this.voluntario = voluntario;
	}
}
