package com.CEDICA.model;





public class Coordinador extends Rol_En_Clase {
	public    Boolean es_designado;

	public Boolean getEs_designado() {
		return es_designado;
	}

	public void setEs_designado(Boolean es_designado) {
		this.es_designado = es_designado;
	}
}
