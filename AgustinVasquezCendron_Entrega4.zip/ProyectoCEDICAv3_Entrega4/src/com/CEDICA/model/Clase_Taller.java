package com.CEDICA.model;



public class Clase_Taller extends Clase {
}
