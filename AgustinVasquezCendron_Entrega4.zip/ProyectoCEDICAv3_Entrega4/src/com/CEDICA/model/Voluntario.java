package com.CEDICA.model;

import javax.persistence.*;

@Entity
public class Voluntario extends Persona {
	public    String tel_celular;
	public    String estudios;
	public    String carrera;
	public    String titulo;
	public    String ocupacion;
	public    String tareas;
	public Conductor rol;
	public String getTel_celular() {
		return tel_celular;
	}
	public void setTel_celular(String tel_celular) {
		this.tel_celular = tel_celular;
	}
	public String getEstudios() {
		return estudios;
	}
	public void setEstudios(String estudios) {
		this.estudios = estudios;
	}
	public String getCarrera() {
		return carrera;
	}
	public void setCarrera(String carrera) {
		this.carrera = carrera;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getOcupacion() {
		return ocupacion;
	}
	public void setOcupacion(String ocupacion) {
		this.ocupacion = ocupacion;
	}
	public String getTareas() {
		return tareas;
	}
	public void setTareas(String tareas) {
		this.tareas = tareas;
	}
	public Conductor getRol() {
		return rol;
	}
	public void setRol(Conductor rol) {
		this.rol = rol;
	}
}
