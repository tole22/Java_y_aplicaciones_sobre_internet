package com.CEDICA.model;

import javax.persistence.Entity;


@Entity
public class Solicitud_En_Evaluacion extends Estado_Solicitud {
}
