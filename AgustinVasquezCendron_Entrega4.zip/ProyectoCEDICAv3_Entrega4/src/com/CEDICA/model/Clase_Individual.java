package com.CEDICA.model;





public class Clase_Individual extends Clase {
}
