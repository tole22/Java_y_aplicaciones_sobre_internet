package com.CEDICA.model;

import javax.persistence.Entity;


@Entity
public class Solicitud_En_Admision extends  Estado_Solicitud {
}
